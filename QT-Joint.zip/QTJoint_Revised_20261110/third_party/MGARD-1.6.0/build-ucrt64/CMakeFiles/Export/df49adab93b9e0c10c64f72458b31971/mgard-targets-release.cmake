#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mgard::mgard" for configuration "Release"
set_property(TARGET mgard::mgard APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mgard::mgard PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmgard.a"
  )

list(APPEND _cmake_import_check_targets mgard::mgard )
list(APPEND _cmake_import_check_files_for_mgard::mgard "${_IMPORT_PREFIX}/lib/libmgard.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
