/*
 * Copyright 2022, Oak Ridge National Laboratory.
 * MGARD-X: MultiGrid Adaptive Reduction of Data Portable across GPUs and CPUs
 * Author: Jieyang Chen (chenj3@ornl.gov)
 * Date: March 17, 2022
 */

#include "mgard-x/DataRefactoring/SingleDimension/Coefficient/CoefficientsRestore.hpp"
// clang-format off
namespace mgard_x {

namespace data_refactoring {

namespace single_dimension {

template void CoefficientsRestore<2, float, SERIAL>(
    DIM current_dim, SubArray<1, float, SERIAL> ratio,
    SubArray<2, float, SERIAL> v,
    SubArray<2, float, SERIAL> coarse,
    SubArray<2, float, SERIAL> coeff, int queue_idx);

} // namespace single_dimension

} // namespace data_refactoring

} // namespace mgard_x
// clang-format on
