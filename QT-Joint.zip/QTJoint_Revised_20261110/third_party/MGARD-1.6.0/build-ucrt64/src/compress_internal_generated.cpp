#include "compress_internal.hpp"
namespace mgard {
MemoryBuffer<const unsigned char> decompress(
const pb::Header & header,
const std::size_t dimension,
void const * const data,
const std::size_t size
) {
switch (dimension) {
case 1: {
return decompress_N<1>(header, data, size);
}
case 2: {
return decompress_N<2>(header, data, size);
}
case 3: {
return decompress_N<3>(header, data, size);
}
case 4: {
return decompress_N<4>(header, data, size);
}
default: {
throw std::runtime_error("unrecognized topology dimension");
}
}
}
}