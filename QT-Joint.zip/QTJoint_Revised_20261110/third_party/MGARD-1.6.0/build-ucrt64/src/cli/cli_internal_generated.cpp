#include "cli/cli_internal.hpp"
namespace cli {
int compress(
const CompressionArguments & arguments,
const std::size_t dimension
) {
switch (dimension) {
case 1: {
return compress_N<1>(arguments);
}
case 2: {
return compress_N<2>(arguments);
}
case 3: {
return compress_N<3>(arguments);
}
case 4: {
return compress_N<4>(arguments);
}
default: {
throw std::runtime_error("unrecognized topology dimension");
}
}
}
}