# FT-AED 张量化数据包说明

## 1. 数据来源

- 数据集：Freeway Traffic Anomalous Event Detection（FT-AED）
- 官方项目页：https://acoursey3.github.io/ft-aed/
- 官方数据仓库：https://github.com/acoursey3/freeway-anomaly-data
- 原始文件：`nashville_freeway_anomaly.csv`

## 2. 本数据包包含的文件

- `FT_AED_tensor_ready.npz`：已经转换为三维张量的数据。
- `FT_AED_metadata.json`：张量形状、日期边界、校验值等。
- `prepare_ft_aed.py`：由官方 CSV 重新生成 NPZ 的脚本。
- `LICENSE_FT_AED.txt`：官方仓库中的 BSD 3-Clause 许可说明。

## 3. 张量结构

```python
import numpy as np

z = np.load("FT_AED_tensor_ready.npz", allow_pickle=False)

speed = z["speed"]          # (49, 4, 19200)
volume = z["volume"]        # (49, 4, 19200)
occupancy = z["occupancy"]  # (49, 4, 19200)
```

三个张量均采用：

```text
(空间位置 milemarker, 车道 lane, 时间 time)
```

即：

```text
49 个里程位置 × 4 条车道 × 19200 个时间点
```

若需要一个 `49 × 12 × T` 的多特征三维张量：

```python
D = np.concatenate([speed, volume, occupancy], axis=1)
# D.shape == (49, 12, 19200)
```

第二维顺序为：

```text
speed_lane1...speed_lane4,
volume_lane1...volume_lane4,
occupancy_lane1...occupancy_lane4
```

## 4. 异常标签

```python
human_label = z["human_label"]      # (19200,)
crash_record = z["crash_record"]    # (19200,)
```

官方 CSV 中这两个标签是时间级标签，并在同一时间点的 49 个里程位置上重复，而不是精确到某个里程位置。

构造与 `speed` 同形状的异常掩码：

```python
M_human = np.broadcast_to(
    human_label[None, None, :].astype(bool),
    speed.shape,
)

M_crash = np.broadcast_to(
    crash_record[None, None, :].astype(bool),
    speed.shape,
)
```

正式实验建议分别报告：

1. `human_label`：人工确认的异常；
2. `crash_record`：官方事故记录；
3. `human_label OR crash_record`：联合事件标签。

## 5. 按天切分

20 个工作日被沿时间维拼接。每一天有 960 个时间点，采样间隔为 30 秒。

```python
offsets = z["day_offsets"]
days = z["days"]

for i, day in enumerate(days):
    left, right = offsets[i], offsets[i + 1]
    D_day = speed[:, :, left:right]  # (49, 4, 960)
```

TRPCA 实验推荐按天分别分解，不要直接跨日期执行一次分解，否则相邻日期之间的跳变可能被当成异常。

## 6. 推荐实验输入

### 单变量实验

分别使用：

```text
D_speed     = 49 × 4 × 960
D_volume    = 49 × 4 × 960
D_occupancy = 49 × 4 × 960
```

### 多变量实验

```python
D_all = np.concatenate(
    [speed[:, :, left:right],
     volume[:, :, left:right],
     occupancy[:, :, left:right]],
    axis=1,
)
# (49, 12, 960)
```

建议先对每一类特征独立使用 robust scaling，再拼接，以避免速度、流量和占有率量纲不同。

## 7. 文件校验

原始 CSV SHA-256：

```text
9bde51bd3e57ebffec6145b16f6b3ea724394a748f1d8483c9485e8a6ab42490
```

张量 NPZ SHA-256：

```text
15cb623a6f0aa0c4245f9e67612c1a84bdd4a2a13d6d30b8620ed9cb5d1e2ed7
```
