#!/usr/bin/env python3
"""Convert the official FT-AED CSV into tensors for low-rank/TRPCA experiments.

Output layout
-------------
speed, volume, occupancy: (space=49, lane=4, time=19200)
human_label, crash_record: (time=19200,)

The 20 weekdays are concatenated along time. Use day_offsets to split them
before TRPCA if you want to avoid discontinuities between days.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

LANES = (1, 2, 3, 4)
MODALITIES = ("speed", "volume", "occ")


def sha256sum(path: Path, block_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(block_size):
            h.update(chunk)
    return h.hexdigest()


def build_tensors(csv_path: Path) -> dict[str, np.ndarray]:
    df = pd.read_csv(csv_path)
    expected = {
        "day", "unix_time", "milemarker", "human_label", "crash_record",
        *{f"lane{lane}_{m}" for lane in LANES for m in MODALITIES},
    }
    missing = sorted(expected.difference(df.columns))
    if missing:
        raise ValueError(f"CSV is missing columns: {missing}")

    df = df.sort_values(["day", "unix_time", "milemarker"], kind="mergesort")
    milemarkers = np.sort(df["milemarker"].unique()).astype(np.float32)
    days = np.sort(df["day"].unique()).astype(np.int16)
    if len(milemarkers) != 49:
        raise ValueError(f"Expected 49 milemarkers, found {len(milemarkers)}")

    speed_days: list[np.ndarray] = []
    volume_days: list[np.ndarray] = []
    occupancy_days: list[np.ndarray] = []
    time_days: list[np.ndarray] = []
    human_days: list[np.ndarray] = []
    crash_days: list[np.ndarray] = []
    day_id_per_time: list[np.ndarray] = []
    offsets = [0]

    for day in days:
        part = df[df["day"] == day].copy()
        times = np.sort(part["unix_time"].unique()).astype(np.int64)
        n_t = len(times)
        if n_t != 960:
            raise ValueError(f"Day {day}: expected 960 timestamps, found {n_t}")

        counts = part.groupby("unix_time", sort=False).size().to_numpy()
        if not np.all(counts == len(milemarkers)):
            raise ValueError(f"Day {day}: incomplete milemarker grid")

        # Rows are ordered time-major, milemarker-minor.
        def tensor_for(modality: str) -> np.ndarray:
            cols = [f"lane{lane}_{modality}" for lane in LANES]
            arr = part[cols].to_numpy(dtype=np.float32)
            arr = arr.reshape(n_t, len(milemarkers), len(LANES))
            return np.transpose(arr, (1, 2, 0))  # (space, lane, time)

        speed_days.append(tensor_for("speed"))
        volume_days.append(tensor_for("volume"))
        occupancy_days.append(tensor_for("occ"))
        time_days.append(times)
        day_id_per_time.append(np.full(n_t, day, dtype=np.int16))

        # Labels are timestamp-level in the released CSV and repeat over milemarkers.
        labels = part.groupby("unix_time", sort=True)[["human_label", "crash_record"]].first()
        human_days.append(labels["human_label"].to_numpy(dtype=np.uint8))
        crash_days.append(labels["crash_record"].to_numpy(dtype=np.uint8))
        offsets.append(offsets[-1] + n_t)

    return {
        "speed": np.concatenate(speed_days, axis=2),
        "volume": np.concatenate(volume_days, axis=2),
        "occupancy": np.concatenate(occupancy_days, axis=2),
        "human_label": np.concatenate(human_days),
        "crash_record": np.concatenate(crash_days),
        "unix_time": np.concatenate(time_days),
        "day_id": np.concatenate(day_id_per_time),
        "days": days,
        "day_offsets": np.asarray(offsets, dtype=np.int32),
        "milemarkers": milemarkers,
        "lanes": np.asarray(LANES, dtype=np.int8),
        "feature_names": np.asarray(
            [f"lane{lane}_{m}" for m in ("speed", "volume", "occupancy") for lane in LANES]
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", type=Path)
    parser.add_argument("--output", type=Path, default=Path("FT_AED_tensor_ready.npz"))
    parser.add_argument("--metadata", type=Path, default=Path("FT_AED_metadata.json"))
    args = parser.parse_args()

    tensors = build_tensors(args.csv)
    np.savez_compressed(args.output, **tensors)

    metadata = {
        "source_file": args.csv.name,
        "source_sha256": sha256sum(args.csv),
        "output_file": args.output.name,
        "output_sha256": sha256sum(args.output),
        "tensor_layout": {
            "speed": ["milemarker", "lane", "time"],
            "volume": ["milemarker", "lane", "time"],
            "occupancy": ["milemarker", "lane", "time"],
        },
        "shape": list(tensors["speed"].shape),
        "days": tensors["days"].tolist(),
        "day_offsets": tensors["day_offsets"].tolist(),
        "human_anomaly_timestamps": int(tensors["human_label"].sum()),
        "crash_timestamps": int(tensors["crash_record"].sum()),
        "notes": [
            "The official CSV labels are timestamp-level and repeat across milemarkers.",
            "Split by day_offsets before TRPCA to avoid artificial discontinuities at day boundaries.",
            "For a 49x12xT tensor, concatenate speed, volume, and occupancy along axis=1.",
        ],
    }
    args.metadata.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(metadata, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
