# 推荐异常时空数据集下载入口

## 1. FT-AED（优先推荐，数值型）

官方介绍：
https://acoursey3.github.io/ft-aed/

官方仓库：
https://github.com/acoursey3/freeway-anomaly-data

官方 CSV：
https://github.com/acoursey3/freeway-anomaly-data/raw/refs/heads/main/nashville_freeway_anomaly.csv

本数据包已经提供原始 CSV 和转换后的 NPZ。

## 2. UCSD Ped1/Ped2（最适合验证 TRPCA 机制）

官方页面：
https://www.svcl.ucsd.edu/projects/anomaly/dataset.htm

官方完整压缩包（Ped1 + Ped2，约 707 MB）：
https://www.svcl.ucsd.edu/projects/anomaly/UCSD_Anomaly_Dataset.tar.gz

官方 MD5：
```text
5006421b89885f45a6f93b041145f2eb
```

下载命令：
```bash
wget -c https://www.svcl.ucsd.edu/projects/anomaly/UCSD_Anomaly_Dataset.tar.gz
md5sum UCSD_Anomaly_Dataset.tar.gz
```

## 3. CUHK Avenue

官方页面：
https://www.cse.cuhk.edu.hk/leojia/projects/detectabnormal/dataset.html

视频数据：
https://www.cse.cuhk.edu.hk/leojia/projects/detectabnormal/Avenue_Dataset.zip

空间矩形标注：
https://www.cse.cuhk.edu.hk/leojia/projects/detectabnormal/ground_truth_demo.zip

下载命令：
```bash
wget -c https://www.cse.cuhk.edu.hk/leojia/projects/detectabnormal/Avenue_Dataset.zip
wget -c https://www.cse.cuhk.edu.hk/leojia/projects/detectabnormal/ground_truth_demo.zip
```

## 4. ShanghaiTech Campus

官方页面：
https://svip-lab.github.io/dataset/campus_dataset.html

官方 OneDrive：
https://1drv.ms/u/s%21AjjUqiJZsj8whLt-1ABerTT-9eH9Ag?e=eJbY6Y

也可以通过 Anomalib 自动准备：
https://anomalib.readthedocs.io/en/v1.0.1/markdown/guides/reference/data/video/shanghaitech.html

## 5. NWPU Campus

官方页面：
https://campusvad.github.io/

数据约 76.6 GB。官方页面提供：
- 百度网盘，提取码 `il54`
- Google Drive

该数据集限制为非商业学术研究，并禁止未经许可的再分发，所以应从官方页面自行下载。

## 6. Street Scene

MERL 官方页面：
https://www.merl.com/research/downloads/StreetScene

Zenodo 正式数据记录：
https://doi.org/10.5281/zenodo.10870471

具体版本：
https://zenodo.org/records/10870472

压缩包约 49 GB，解压后约 46 GB：
https://zenodo.org/records/10870472/files/StreetScene.zip?download=1

MD5：
```text
a74c51e99881c860d97e1ebb51ee1f2c
```

## 7. WADI

数据说明：
https://www.sutd.edu.sg/itrust/itrust-labs/datasets/dataset-characteristics/wadi/

官方申请页面：
https://www.sutd.edu.sg/itrust/request-for-datasets/

WADI 需要填写姓名、学校/机构邮箱和用途，由官方发送访问方式，不能代替用户提交申请。

## 8. MAWI / MAWILab

MAWI 原始网络流量：
https://mawi.wide.ad.jp/mawi/

MAWILab 异常标签：
https://www.fukuda-lab.org/mawilab/

MAWILab 历史标签索引：
https://www.fukuda-lab.org/mawilab/v1.1/index.html

使用时需要同时下载：
1. MAWI 中指定日期的 PCAP；
2. MAWILab 中同一天的 XML 异常标签。

MAWI 数据仅限研究用途，并要求遵守其隐私保护规则。
